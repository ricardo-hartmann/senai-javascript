let formulario = document.getElementById("formCadastro");

formulario.addEventListener("submit", function(evento){
    evento.preventDefault(); 

    const nomeDigitado = document.getElementById("username").value;
    const senhaDigitada = document.getElementById("senha").value;
    const emailDigitado = document.getElementById("email").value;

    const validaSenha = document.getElementById("msg")

    const meuInput = document.getElementById("senha");
    meuInput.addEventListener("input", function(event) {
        console.log("Valor Atual:", event.target.value)
    })

    if (senhaDigitada.length < 6) {
        msg.textContent = "Senha muito curta";
        msg.style.color = "red";
    } else {
        msg.textContent = "Senha adequada"
        msg.style.color = "green"

        const listaUsuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

        const novoUsuario = {
            username: nomeDigitado,
            senha: senhaDigitada,
            email: emailDigitado,
            acessos: 0,
        }
    
        listaUsuarios.push(novoUsuario)
        console.log(listaUsuarios)
        localStorage.setItem("usuarios", JSON.stringify(listaUsuarios))
        formulario.reset();
    }




// senhaDigitada.addEventListener("input", function(input){
//     if (senhaDigitada.length < 6){
//         alert("Senha muito curta")
//     }
// })
})