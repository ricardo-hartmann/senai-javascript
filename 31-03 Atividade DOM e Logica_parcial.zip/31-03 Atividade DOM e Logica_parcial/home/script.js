const usuarioLogado = localStorage.getItem("usuarioLogado")

if (!usuarioLogado) {
    alert("Usuário não logado. Redirecionando...")
    window.location.href = "../login/index.html"

} else {
    const dados = JSON.parse(usuarioLogado)
    document.getElementById('user-info').innerText = `Bem-vindo, ${dados.username}\n\n Seus dados cadastrais abaixo: \nNome de cadastro: ${dados.username}\n E-mail cadastrado: ${dados.email}\n Sua senha: ${dados.senha}\n Este é seu acesso de nº ${dados.acesso}`;
    dados.acessos++;
    
}





// function contadorAcessos (index) {
//     const dadosLocal = localStorage.getItem("usuarios");
//     if (dadosLocal) {
//         let lista = JSON.parse(dadosLocal);
//         if (lista[index]) {
//             lista[index].acessos += 1;

//             localStorage.setItem("usuarios", JSON.stringify(lista));

//             document.getElementById("user-info").innerText = `Acessos atualizados: ${lista[index].acessos}`;
//         }
//     }
// }






// const usuarioLogado = localStorage.getItem("usuarioLogado");
// if (!usuarioLogado) {
//     alert("Acesso negado! Faça o Login")
//     window.location.href = "../login/index.html"
// } else {
//     const dadosUsuario = JSON.parse(usuarioLogado);
//     const nomeBoasVindas = document.getElementById("userNome");
//     nomeBoasVindas.innerHTML = dadosUsuario.nome;
// }