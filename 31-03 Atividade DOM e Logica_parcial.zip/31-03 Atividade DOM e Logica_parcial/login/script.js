let formulario = document.getElementById("formLogin");

formulario.addEventListener("submit", function(evento){
    evento.preventDefault();

    const emailDigitado = document.getElementById("emailLogin").value;
    const senhaDigitada = document.getElementById("senhaLogin").value;

    const listaUsuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    const usuarioJaExiste = listaUsuarios.find(function(usuario){
        return usuario.email === emailDigitado && usuario.senha === senhaDigitada;
    });

    if (usuarioJaExiste) {
        alert("Login efetuado com sucesso!");

        localStorage.setItem("usuarioLogado", JSON.stringify(usuarioJaExiste));
        window.location.href = "../home/index.html"

    } else {
        alert("Credenciais inválidas");
    }

    formulario.reset();
})