let formulario = document.getElementById("verificarEmail");

const emailDigitado = document.getElementById("email").value;
